### Hexlet tests and linter status:
[![Actions Status](https://github.com/goryay/python-project-52/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/goryay/python-project-52/actions)
<a href="https://codeclimate.com/github/goryay/python-project-52/maintainability"><img src="https://api.codeclimate.com/v1/badges/ddfd2e3ab4610dacd1bc/maintainability" /></a>
<a href="https://codeclimate.com/github/goryay/python-project-52/test_coverage"><img src="https://api.codeclimate.com/v1/badges/ddfd2e3ab4610dacd1bc/test_coverage" /></a>

[WEB](https://task-manager-fwnu.onrender.com/) version

